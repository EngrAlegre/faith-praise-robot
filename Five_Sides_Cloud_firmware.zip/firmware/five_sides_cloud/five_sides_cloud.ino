/* ============================================================================
   FIVE SIDES · cloud-direct firmware  (no laptop, no server)
   ----------------------------------------------------------------------------
   Faith's robot and Praise's robot run THIS SAME SKETCH. The only difference
   is the config block below - change ROBOT_OWNER and the voice, flash the
   second board.

   WHAT HAPPENS WHEN THEY PRESS THE BUTTON
     1. records until they stop talking (or 6 s)
     2. Groq Whisper        audio -> text        (free tier)
     3. Ollama Cloud        text  -> answer+face (your key, DeepSeek)
     4. Google TTS          answer -> PCM audio  (free tier)
     5. the OLED shows the face, the speaker talks

   LIBRARIES:  ArduinoJson, U8g2
   BOARD:      ESP32S3 Dev Module, PSRAM: OPI, Flash 16MB, Partition Huge APP
   ========================================================================== */

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <driver/i2s_std.h>

// ============================ CONFIG - EDIT ME =============================
#define ROBOT_OWNER   "Faith"
#define ROBOT_AGE     "11"

#define WIFI_SSID     "YOUR_WIFI"
#define WIFI_PASS     "YOUR_PASSWORD"

// Ollama Cloud  ->  ollama.com  ->  API keys
#define OLLAMA_KEY    "YOUR_OLLAMA_KEY"
#define OLLAMA_HOST   "ollama.com"
#define OLLAMA_MODEL  "deepseek-v4.1-flash"     // copy the exact id from ollama.com

// Groq console -> API keys  (free account)
#define GROQ_KEY      "YOUR_GROQ_KEY"
#define GROQ_HOST     "api.groq.com"
#define GROQ_STT      "whisper-large-v3-turbo"

// Google Cloud -> enable "Cloud Text-to-Speech API" -> API key
#define GTTS_KEY      "YOUR_GOOGLE_KEY"
#define GTTS_HOST     "texttospeech.googleapis.com"
#define GTTS_VOICE    "en-US-Neural2-F"         // warm female; or -Neural2-D (male)
#define GTTS_LANG     "en-US"
// ===========================================================================

// ------------------------------- pins --------------------------------------
const int PIN_SDA = 8, PIN_SCL = 9;                       // OLED
const int PIN_I2S_OUT_BCLK = 4, PIN_I2S_OUT_LRC = 5, PIN_I2S_OUT_DIN = 6;
const int PIN_I2S_IN_BCLK  = 15, PIN_I2S_IN_WS  = 16, PIN_I2S_IN_SD  = 17;
const int PIN_BUTTON = 18;
const int PIN_LED = 38;

// ------------------------------- audio -------------------------------------
static const int MIC_HZ  = 16000;
static const int PLAY_HZ = 24000;                          // Google LINEAR16 output
static const int MAX_REC_SECONDS = 6;
static const size_t MAX_REC_SAMPLES = MIC_HZ * MAX_REC_SECONDS;
static const size_t MAX_TTS_BYTES = 700 * 1024;            // ~7 s of 24 kHz PCM, base64 already decoded

int16_t* recBuf = nullptr;                                  // PSRAM
uint8_t* ttsBuf = nullptr;                                  // PSRAM
size_t   recLen = 0;

i2s_chan_handle_t txChan = nullptr, rxChan = nullptr;

// keep one TLS connection per host alive - a fresh handshake is 300-800 ms
WiFiClientSecure sttCli, llmCli, ttsCli;

// ------------------------------- face --------------------------------------
U8G2_SSD1309_128X64_NONAME0_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);

enum Mood { M_IDLE, M_HAPPY, M_THINK, M_TALK, M_LOVE, M_SLEEP, M_SAD };

void face(Mood m, float open = 1.0f, int look = 0) {
  const int ex1 = 38, ex2 = 90, ey = 26, er = 13;
  oled.clearBuffer();
  oled.setDrawColor(1);
  if (open < 0.1f || m == M_SLEEP) {
    oled.drawRBox(ex1 - er, ey - 2, er * 2, 4, 2);
    oled.drawRBox(ex2 - er, ey - 2, er * 2, 4, 2);
  } else if (m == M_HAPPY || m == M_LOVE) {
    for (int e = 0; e < 2; e++) {
      int cx = e ? ex2 : ex1;
      oled.drawDisc(cx, ey + 4, er);
      oled.setDrawColor(0);
      oled.drawBox(cx - er - 2, ey + 4, er * 2 + 4, er + 6);
      oled.setDrawColor(1);
    }
  } else if (m == M_SAD) {
    for (int e = 0; e < 2; e++) {
      int cx = e ? ex2 : ex1;
      oled.drawDisc(cx, ey, er);
      oled.setDrawColor(0);
      oled.drawBox(cx - er - 2, ey - er - 2, er * 2 + 4, er + 2);
      oled.setDrawColor(1);
    }
  } else {
    int half = (int)(er * open);
    for (int e = 0; e < 2; e++) {
      int cx = e ? ex2 : ex1;
      oled.drawDisc(cx, ey, er);
      oled.setDrawColor(0);
      oled.drawDisc(cx + look, ey, 5);
      oled.drawBox(cx - er, ey - er, er * 2, er - half);
      oled.drawBox(cx - er, ey + half, er * 2, er - half);
      oled.setDrawColor(1);
      oled.drawDisc(cx + look - 2, ey - 3, 1);
    }
  }
  switch (m) {
    case M_HAPPY: oled.drawCircle(64, 42, 11, U8G2_DRAW_LOWER_LEFT | U8G2_DRAW_LOWER_RIGHT); break;
    case M_LOVE:  oled.drawDisc(64, 47, 4); break;
    case M_TALK:  oled.drawRBox(56, 44, 16, 10, 4); break;
    case M_SAD:   oled.drawCircle(64, 50, 11, U8G2_DRAW_UPPER_LEFT | U8G2_DRAW_UPPER_RIGHT); break;
    case M_SLEEP: break;
    default:      oled.drawRBox(56, 47, 16, 4, 2); break;
  }
  oled.sendBuffer();
}

// ------------------------------- i2s ---------------------------------------
void audioBegin() {
  i2s_chan_config_t c0 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
  i2s_new_channel(&c0, &txChan, nullptr);
  i2s_std_config_t s0 = {
    .clk_cfg  = I2S_STD_CLK_DEFAULT_CONFIG(PLAY_HZ),
    .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
    .gpio_cfg = { .mclk = I2S_GPIO_UNUSED, .bclk = (gpio_num_t)PIN_I2S_OUT_BCLK,
                  .ws = (gpio_num_t)PIN_I2S_OUT_LRC, .dout = (gpio_num_t)PIN_I2S_OUT_DIN,
                  .din = I2S_GPIO_UNUSED, .invert_flags = { false, false, false } },
  };
  i2s_channel_init_std_mode(txChan, &s0);
  i2s_channel_enable(txChan);

  i2s_chan_config_t c1 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_MASTER);
  i2s_new_channel(&c1, nullptr, &rxChan);
  i2s_std_config_t s1 = {
    .clk_cfg  = I2S_STD_CLK_DEFAULT_CONFIG(MIC_HZ),
    .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO),
    .gpio_cfg = { .mclk = I2S_GPIO_UNUSED, .bclk = (gpio_num_t)PIN_I2S_IN_BCLK,
                  .ws = (gpio_num_t)PIN_I2S_IN_WS, .dout = I2S_GPIO_UNUSED,
                  .din = (gpio_num_t)PIN_I2S_IN_SD, .invert_flags = { false, false, false } },
  };
  i2s_channel_init_std_mode(rxChan, &s1);
  i2s_channel_enable(rxChan);
}

void playPcm(const uint8_t* data, size_t bytes) {
  size_t off = 0, wrote = 0;
  while (off + 1 < bytes) {
    if (i2s_channel_write(txChan, data + off, bytes - off, &wrote, 1000) != ESP_OK) break;
    if (!wrote) break;
    off += wrote;
  }
}

// -------------------------- record with voice activity ----------------------
// Records until the room goes quiet for QUIET_MS, or MAX_REC_SECONDS.
// Returns the number of samples captured.
size_t recordSpeech() {
  const int   BLOCK = 256;
  const float THRESHOLD = 700.0f;      // raise if it triggers on room noise
  const int   QUIET_MS = 700;
  const int   MIN_MS   = 300;

  int32_t raw[BLOCK];
  size_t total = 0;
  bool  spoken = false;
  uint32_t lastLoud = millis();
  uint32_t start = millis();

  while (total < MAX_REC_SAMPLES) {
    size_t got = 0;
    if (i2s_channel_read(rxChan, raw, sizeof(raw), &got, 300) != ESP_OK) continue;
    size_t n = got / sizeof(int32_t);
    if (!n) continue;

    float peak = 0;
    for (size_t i = 0; i < n && total < MAX_REC_SAMPLES; i++) {
      int16_t s = (int16_t)(raw[i] >> 16);          // INMP441: 24-bit left-justified in 32
      recBuf[total++] = s;
      float a = fabsf(s);
      if (a > peak) peak = a;
    }
    if (peak > THRESHOLD) { spoken = true; lastLoud = millis(); }
    bool longEnough = (millis() - start) > MIN_MS;
    if (spoken && longEnough && (millis() - lastLoud) > QUIET_MS) break;
  }
  recLen = total;
  return total;
}

size_t wavHeader(uint8_t* h, size_t pcm, int rate) {
  uint32_t chunk = 36 + pcm, sub = pcm, byteRate = rate * 2;
  uint16_t ch = 1, align = 2, bits = 16, pcmFmt = 1;
  uint32_t sixteen = 16;
  memcpy(h, "RIFF", 4); memcpy(h + 4, &chunk, 4); memcpy(h + 8, "WAVE", 4);
  memcpy(h + 12, "fmt ", 4); memcpy(h + 16, &sixteen, 4); memcpy(h + 20, &pcmFmt, 2);
  memcpy(h + 22, &ch, 2); memcpy(h + 24, &rate, 4); memcpy(h + 28, &byteRate, 4);
  memcpy(h + 32, &align, 2); memcpy(h + 34, &bits, 2); memcpy(h + 36, "data", 4);
  memcpy(h + 40, &sub, 4);
  return 44;
}

// ------------------------------- STEP 2: Groq whisper ------------------------
bool transcribe(String& outText) {
  if (!recLen) return false;

  size_t pcmBytes = recLen * 2;
  size_t total = 44 + pcmBytes;
  uint8_t* body = (uint8_t*)ps_malloc(total);
  if (!body) return false;
  wavHeader(body, pcmBytes, MIC_HZ);
  memcpy(body + 44, recBuf, pcmBytes);

  // multipart envelope
  String head = "--BOUND\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\n"
                "Content-Type: audio/wav\r\n\r\n";
  String tail = "\r\n--BOUND\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n" +
                String(GROQ_STT) +
                "\r\n--BOUND\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\nen"
                "\r\n--BOUND\r\nContent-Disposition: form-data; name=\"response_format\"\r\n\r\njson"
                "\r\n--BOUND--\r\n";

  HTTPClient http;
  if (!http.begin(sttCli, "https://" GROQ_HOST "/openai/v1/audio/transcriptions")) { free(body); return false; }
  http.setReuse(true);
  http.setTimeout(20000);
  http.addHeader("Authorization", "Bearer " GROQ_KEY);
  http.addHeader("Content-Type", "multipart/form-data; boundary=BOUND");

  size_t len = head.length() + total + tail.length();
  uint8_t* mp = (uint8_t*)ps_malloc(len);
  if (!mp) { free(body); http.end(); return false; }
  size_t p = 0;
  memcpy(mp + p, head.c_str(), head.length()); p += head.length();
  memcpy(mp + p, body, total); p += total;
  memcpy(mp + p, tail.c_str(), tail.length());
  free(body);

  int code = http.POST(mp, len);
  free(mp);
  bool ok = false;
  if (code == 200) {
    JsonDocument doc;
    if (!deserializeJson(doc, http.getString())) {
      const char* t = doc["text"] | "";
      outText = t;
      outText.trim();
      ok = outText.length() > 0;
    }
  } else {
    Serial.printf("STT http %d %s\n", code, http.getString().c_str());
  }
  http.end();
  return ok;
}

// --------------------------- STEP 3: Ollama Cloud ---------------------------
// Keeps the last few turns so it feels like a conversation, and remembers
// who it belongs to.
String history[8];          // ring of "user: ..." / "bot: ..."
int    histCount = 0;

void pushHistory(const String& who, const String& what) {
  if (histCount < 8) history[histCount] = who + ": " + what;
  else {
    for (int i = 1; i < 8; i++) history[i - 1] = history[i];
    history[7] = who + ": " + what;
  }
  if (histCount < 8) histCount++;
}

bool think(const String& heard, String& say, String& faceName) {
  JsonDocument doc;
  doc["model"]  = OLLAMA_MODEL;
  doc["stream"] = false;
  doc["format"] = "json";
  JsonArray msgs = doc["messages"].to<JsonArray>();

  String sys = String("You are Five Sides, a small friendly desk robot that belongs to ") +
               ROBOT_OWNER + ", who is " + ROBOT_AGE + " years old. "
               "You have one screen for a face and a speaker. You are curious, warm and playful. "
               "Reply in at most 12 words, plain simple English, no lists, no emoji. "
               "You may ask one short question back. "
               "Always answer with JSON: {\"say\":\"...\",\"face\":\"idle|happy|think|love|sleep|sad\"}";
  JsonObject s0 = msgs.add<JsonObject>();
  s0["role"] = "system"; s0["content"] = sys;
  for (int i = 0; i < histCount; i++) {
    JsonObject m = msgs.add<JsonObject>();
    bool isBot = history[i].startsWith("bot:");
    m["role"]    = isBot ? "assistant" : "user";
    m["content"] = history[i].substring(isBot ? 4 : 5);
  }
  JsonObject u = msgs.add<JsonObject>();
  u["role"] = "user"; u["content"] = heard;

  String payload; serializeJson(doc, payload);

  HTTPClient http;
  if (!http.begin(llmCli, "https://" OLLAMA_HOST "/api/chat")) return false;
  http.setReuse(true);
  http.setTimeout(30000);
  http.addHeader("Authorization", "Bearer " OLLAMA_KEY);
  http.addHeader("Content-Type", "application/json");

  int code = http.POST(payload);
  bool ok = false;
  if (code == 200) {
    JsonDocument r;
    if (!deserializeJson(r, http.getString())) {
      const char* content = r["message"]["content"] | "";
      JsonDocument inner;
      if (!deserializeJson(inner, content)) {
        say      = String((const char*)(inner["say"] | ""));
        faceName = String((const char*)(inner["face"] | "idle"));
        ok = say.length() > 0;
      }
    }
  } else {
    Serial.printf("LLM http %d %s\n", code, http.getString().c_str());
  }
  http.end();
  return ok;
}

// ----------------------------- STEP 4: Google TTS ---------------------------
int b64val(char c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '+') return 62;
  if (c == '/') return 63;
  return -1;
}

size_t b64decode(const char* in, size_t inLen, uint8_t* out, size_t outMax) {
  size_t o = 0; int buf = 0, bits = 0;
  for (size_t i = 0; i < inLen && o < outMax; i++) {
    int v = b64val(in[i]);
    if (v < 0) continue;
    buf = (buf << 6) | v; bits += 6;
    if (bits >= 8) { bits -= 8; out[o++] = (uint8_t)((buf >> bits) & 0xFF); }
  }
  return o;
}

bool speak(const String& text) {
  JsonDocument doc;
  doc["input"]["text"] = text;
  doc["voice"]["languageCode"] = GTTS_LANG;
  doc["voice"]["name"]         = GTTS_VOICE;
  doc["audioConfig"]["audioEncoding"]    = "LINEAR16";
  doc["audioConfig"]["sampleRateHertz"]  = PLAY_HZ;
  doc["audioConfig"]["speakingRate"]     = 1.0;
  String payload; serializeJson(doc, payload);

  HTTPClient http;
  if (!http.begin(ttsCli, "https://" GTTS_HOST "/v1/text:synthesize")) return false;
  http.setReuse(true);
  http.setTimeout(20000);
  http.addHeader("x-goog-api-key", GTTS_KEY);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(payload);
  bool ok = false;
  if (code == 200) {
    JsonDocument r;
    if (!deserializeJson(r, http.getString())) {
      const char* b64 = r["audioContent"] | "";
      size_t n = b64decode(b64, strlen(b64), ttsBuf, MAX_TTS_BYTES);
      if (n > 44) {
        const uint8_t* pcm = ttsBuf;
        if (!memcmp(ttsBuf, "RIFF", 4)) { pcm += 44; n -= 44; }   // header included
        playPcm(pcm, n);
        ok = true;
      }
    }
  } else {
    Serial.printf("TTS http %d %s\n", code, http.getString().c_str());
  }
  http.end();
  return ok;
}

// ------------------------------- helpers ------------------------------------
Mood moodFrom(const String& s) {
  if (s == "happy") return M_HAPPY;
  if (s == "think") return M_THINK;
  if (s == "talk")  return M_TALK;
  if (s == "love")  return M_LOVE;
  if (s == "sleep") return M_SLEEP;
  if (s == "sad")   return M_SAD;
  return M_IDLE;
}

void chirp(bool good) {
  face(good ? M_HAPPY : M_SAD);
  delay(400);
}

// ------------------------------- setup / loop -------------------------------
void setup() {
  Serial.begin(115200);
  delay(200);

  Wire.begin(PIN_SDA, PIN_SCL);
  oled.begin();
  oled.setBusClock(400000);
  face(M_IDLE);

  audioBegin();
  recBuf = (int16_t*)ps_malloc(MAX_REC_SAMPLES * sizeof(int16_t));
  ttsBuf = (uint8_t*)ps_malloc(MAX_TTS_BYTES);
  if (!recBuf || !ttsBuf) { Serial.println("PSRAM alloc failed"); face(M_SAD); }

  sttCli.setInsecure();      // prototype only: no certificate pinning
  llmCli.setInsecure();
  ttsCli.setInsecure();

  pinMode(PIN_BUTTON, INPUT_PULLUP);
  neopixelWrite(PIN_LED, 12, 12, 30);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                      // latency matters
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  for (int i = 0; i < 80 && WiFi.status() != WL_CONNECTED; i++) delay(250);

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("online: "); Serial.println(WiFi.localIP());
    neopixelWrite(PIN_LED, 0, 30, 12);
    face(M_HAPPY); delay(500);
  } else {
    Serial.println("no wifi");
    neopixelWrite(PIN_LED, 60, 0, 0);
    face(M_SAD);
  }
}

void loop() {
  face(M_IDLE);

  // ---- wait for the button
  while (digitalRead(PIN_BUTTON) == HIGH) {
    delay(20);
  }
  delay(200);

  if (WiFi.status() != WL_CONNECTED) {
    face(M_SAD); speak("I cannot find the wifi."); delay(500);
    return;
  }

  // ---- listen
  face(M_THINK, 1.0f, -3);
  recordSpeech();
  if (recLen < MIC_HZ / 4) {                 // less than 250 ms of audio
    face(M_SAD); delay(600);
    return;
  }

  // ---- ears
  face(M_THINK);
  String heard;
  if (!transcribe(heard)) { face(M_SAD); delay(800); return; }
  Serial.print("heard: "); Serial.println(heard);
  pushHistory("you", heard);

  // ---- brain
  String answer, faceName;
  if (!think(heard, answer, faceName)) {
    face(M_SAD);
    speak("I could not reach my brain.");
    delay(400);
    return;
  }
  Serial.print("say: "); Serial.println(answer);
  pushHistory("bot", answer);

  // ---- face reacts BEFORE the audio, so it feels fast
  face(moodFrom(faceName));
  neopixelWrite(PIN_LED, 30, 12, 30);

  // ---- voice
  face(M_TALK);
  if (!speak(answer)) chirp(false);

  delay(400);
  neopixelWrite(PIN_LED, 12, 12, 30);
  face(M_IDLE);
}
